const mod_emailValidate = require('../controllers/emailValidate.mod');

exports.getUsers = (req, res) => {
    const { name } = req.body;
    const { email } = req.body;
    const { password } = req.body;

        
                      
           async function run() {
            var data = await mod_emailValidate(email);                   
            console.log('Retornou: ' + data);

          }

          run();
         
      
          res.status(400).send({ message: 'rodou' });    
      
};