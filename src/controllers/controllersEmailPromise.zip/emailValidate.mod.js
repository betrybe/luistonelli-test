const res = require('express/lib/response');

function emailValidate(email) {
    return new Promise((resolve,reject) => {
        setTimeout(() => {
            var query = { email: email };
           
            dbo.collection('users').find(query).toArray((_err, result) => {     
                                              
                resolve(result.length);
                        
             });        
            
        },0);


    });    

          
    
           
   
};

module.exports = emailValidate;